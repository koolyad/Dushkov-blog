from django.contrib import admin
from .models import Category, IceCream, Topping, Wrapper

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('title',)

@admin.register(Topping)
class ToppingAdmin(admin.ModelAdmin):
    list_display = ('title',)

@admin.register(Wrapper)
class WrapperAdmin(admin.ModelAdmin):
    list_display = ('title',)

@admin.register(IceCream)
class IceCreamAdmin(admin.ModelAdmin):
    list_display = ('title',)
